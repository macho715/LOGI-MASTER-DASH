# 🚀 HVDC Dashboard - Final Setup Guide

## ✅ Current Status

Based on the logs, your migration is working but encountering duplicate key errors. This means:
- ✅ Database schema is deployed
- ✅ Tables are created
- ✅ Some data (40+ rows) is already in the database
- ⚠️ Migration script needs UPSERT instead of INSERT

---

## 📝 Step-by-Step Completion

### 1. Update Migration Script (UPSERT Mode)

Replace your current `hvdc_migration_script.py` with `hvdc_migration_script_upsert.py`:

```bash
cd "C:\Users\minky\Downloads\HVDC DASH\hvdc-dashboard"

# Copy the new UPSERT script
copy hvdc_migration_script_upsert.py hvdc_migration_script.py
```

### 2. Create .env File for Python

Create a file named `.env` in your project root:

```bash
SUPABASE_URL=https://vnoypalmmyiigxntfdxx.supabase.co
SUPABASE_SERVICE_ROLE_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InZub3lwYWxtbXlpaWd4bnRmZHh4Iiwicm9sZSI6InNlcnZpY2Vfcm9sZSIsImlhdCI6MTc2Nzg5MDE5MCwiZXhwIjoyMDgzNDY2MTkwfQ.oxFwt5V9iuoIP6thcUIy49tjgl-jy2AJ6BxvC_z2wMI
```

### 3. Run Complete Migration with UPSERT

```bash
# Install dependencies (if not already installed)
pip install pandas supabase openpyxl python-dotenv

# Run migration (will update existing records)
python hvdc_migration_script.py
```

**Expected Output:**
```
INFO - Reading Excel file: HVDC_STATUS_1.xlsx
INFO - Loaded 755 rows
INFO - Starting migration of 755 rows
INFO - Row 1: Successfully migrated HVDC-ADOPT-PPL-0001
INFO - Progress: 10/755 rows processed
...
INFO - Progress: 755/755 rows processed
============================================================
MIGRATION STATISTICS
============================================================
Total rows processed: 755
Successful shipments: 755 (or close to it)
Successful containers: 755
Successful warehouses: 755
Errors: 0-10 (minor data issues acceptable)
============================================================
```

### 4. Verify Database

```bash
python verify_database.py
```

**Expected Output:**
```
============================================================
HVDC LOGISTICS DATABASE VERIFICATION
============================================================

📊 Table Statistics:
------------------------------------------------------------
✅ shipments                                755 rows
✅ container_details                        755 rows
✅ warehouse_inventory                      755 rows
⚠️  financial_transactions                   0 rows
⚠️  shipment_tracking_log                    0 rows
⚠️  documents                                 0 rows
------------------------------------------------------------
Total records across all tables: 2265
```

### 5. Update Next.js Environment Variables

Create/Update `.env.local` in your Next.js project:

```bash
# .env.local
NEXT_PUBLIC_SUPABASE_URL=https://vnoypalmmyiigxntfdxx.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InZub3lwYWxtbXlpaWd4bnRmZHh4Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3Njc4OTAxOTAsImV4cCI6MjA4MzQ2NjE5MH0.YOUR_ANON_KEY_HERE
SUPABASE_SERVICE_ROLE_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InZub3lwYWxtbXlpaWd4bnRmZHh4Iiwicm9sZSI6InNlcnZpY2Vfcm9sZSIsImlhdCI6MTc2Nzg5MDE5MCwiZXhwIjoyMDgzNDY2MTkwfQ.oxFwt5V9iuoIP6thcUIy49tjgl-jy2AJ6BxvC_z2wMI
```

⚠️ **IMPORTANT:** You need to also add the `NEXT_PUBLIC_SUPABASE_ANON_KEY` from Supabase Dashboard > Settings > API > anon public key.

### 6. Start Next.js Development Server

```bash
cd "C:\Users\minky\Downloads\HVDC DASH\hvdc-dashboard"

# Start development server
npm run dev
```

### 7. Test the Application

Open your browser:
```
http://localhost:3000
```

**Test API Endpoints:**
```bash
# List all shipments
curl http://localhost:3000/api/shipments

# Get statistics
curl http://localhost:3000/api/statistics

# Filter by vendor
curl "http://localhost:3000/api/shipments?vendor=Prysmian"
```

---

## 🎯 What You Should See

### Dashboard (http://localhost:3000)
- ✅ Total shipments count
- ✅ Status breakdown (pending, in_transit, arrived, delivered)
- ✅ Recent shipments table
- ✅ Statistics cards

### Shipments List (http://localhost:3000/shipments)
- ✅ Filterable table
- ✅ Search by vendor, status, date
- ✅ Pagination
- ✅ Click to view details

### API Responses
```json
{
  "data": [
    {
      "id": "uuid",
      "sct_ship_no": "HVDC-ADOPT-PPL-0001",
      "vendor": "Prysmian",
      "vessel_name": "BBC ASIA",
      "eta": "2023-11-30",
      "status": "delivered"
    }
  ],
  "pagination": {
    "page": 1,
    "limit": 50,
    "total": 755
  }
}
```

---

## 🔧 Troubleshooting

### Issue: "relation does not exist"
**Solution:** Run the SQL schema again in Supabase Dashboard > SQL Editor

### Issue: Duplicate key errors
**Solution:** Use the UPSERT version of migration script (already updated)

### Issue: 403 Forbidden
**Solution:** Check that:
1. Service role key is correct
2. RLS is disabled for migration (can enable after)
3. Network proxy is not blocking requests

### Issue: No data showing in app
**Solution:** 
1. Check `.env.local` has correct keys
2. Restart dev server: `npm run dev`
3. Check browser console for errors

---

## 📊 Database Schema Summary

```
shipments (755 rows expected)
├── 81 columns from Excel
├── Auto-calculated CIF value
├── Status tracking
└── Timestamps

container_details (755 rows)
├── All container types (20DC, 40HQ, etc.)
├── Bulk cargo data
└── Linked to shipments

warehouse_inventory (755 rows)
├── 10 warehouse locations
├── Project allocations
└── Linked to shipments

financial_transactions (0 rows initially)
├── Invoice tracking
├── Payments
└── Customs fees

shipment_tracking_log (auto-populated)
├── Status change events
└── Automatic logging

documents (0 rows initially)
├── File uploads
└── OCR metadata
```

---

## 🚀 Deploy to Production

### Option 1: Vercel (Recommended)

```bash
# Install Vercel CLI
npm i -g vercel

# Login
vercel login

# Deploy
vercel

# Add environment variables
vercel env add NEXT_PUBLIC_SUPABASE_URL
vercel env add NEXT_PUBLIC_SUPABASE_ANON_KEY
vercel env add SUPABASE_SERVICE_ROLE_KEY

# Deploy to production
vercel --prod
```

### Option 2: Docker

```bash
# Build image
docker build -t hvdc-dashboard .

# Run container
docker run -p 3000:3000 \
  -e NEXT_PUBLIC_SUPABASE_URL=https://vnoypalmmyiigxntfdxx.supabase.co \
  -e NEXT_PUBLIC_SUPABASE_ANON_KEY=your_anon_key \
  -e SUPABASE_SERVICE_ROLE_KEY=your_service_key \
  hvdc-dashboard
```

---

## 📈 Next Features to Add

1. **Real-time Updates**
   - WebSocket connections for live tracking
   - Automatic refresh on status changes

2. **Advanced Filtering**
   - Multi-select filters
   - Date range picker
   - Export to Excel

3. **File Upload**
   - Invoice PDF uploads
   - OCR processing
   - Document viewer

4. **Email Notifications**
   - Delayed shipment alerts
   - Customs clearance notifications
   - Delivery confirmations

5. **Mobile App**
   - React Native version
   - Push notifications
   - Offline support

---

## 📞 Support

If you encounter any issues:

1. Check logs: `npm run dev` output
2. Check Supabase logs: Dashboard > Logs
3. Verify database: `python verify_database.py`
4. Check API: `curl http://localhost:3000/api/shipments`

---

## ✅ Completion Checklist

- [ ] SQL schema deployed in Supabase
- [ ] Migration script run successfully (755 rows)
- [ ] Database verified (2265+ total records)
- [ ] `.env.local` configured with both anon and service keys
- [ ] Next.js dev server running
- [ ] Dashboard accessible at http://localhost:3000
- [ ] API endpoints responding correctly
- [ ] Data filtering working
- [ ] Ready for production deployment

---

**Status:** Your database is set up and partially migrated. Complete the UPSERT migration to finish loading all 755 rows, then your HVDC Dashboard will be fully operational! 🎉
