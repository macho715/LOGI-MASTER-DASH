# SYSTEM COMPONENTS — 통합 컴포넌트/모듈 문서

> 목적: “어떤 컴포넌트가 무엇을 책임지는가”를 명확히 하여, 통합 리팩토링 시 중복/누락을 줄입니다.

## 1) 컴포넌트 분류 체계

- **A. Layout Shell**: 페이지 레이아웃/슬롯
- **B. Map Canvas**: MapLibre + deck.gl
- **C. Ops Panels**: 우측 요약 패널
- **D. HVDC Workbench**: KPI, Worklist, DetailDrawer
- **E. State/Domain**: Zustand store, selectors
- **F. Data Layer**: Supabase client, RPC 호출, cache, realtime
- **G. ETL/RDF**: scripts/configs

---

## 2) Frontend — apps/logistics-dashboard

### 2.1 Layout (신규)

| Component | Type | Responsibility | Inputs | Outputs |
|---|---|---|---|---|
| `OpsCockpitPage` | Page(Server/Hybrid) | 전체 3패널 조립, 초기 데이터 프리페치(가능 시) | URL params | Renders layout |
| `MainGrid` | Layout | CSS grid로 슬롯 제공 | children | slot placement |
| `MapSlot/RightSlot/BottomSlot` | Layout | 반응형 슬롯(데스크탑/모바일) | children | responsive UI |

### 2.2 Map Canvas (기존)

| Component | Responsibility | Notes |
|---|---|---|
| `MapView` | 지도 초기화, deck.gl layers 업데이트, hover tooltip | client-only. map 라이브러리 동적 import 권장 |
| `createLocationLayer` | 위치 마커 레이어 | tooltip/select 연결 |
| `createHeatmapLayer` | 이벤트 히트맵 | event window 필터 |
| `createGeofenceLayer` | 지오펜스 폴리곤 | on/off 토글 |
| `createEtaWedgeLayer` | ETA wedge 시각화 | case/location 연동 |

> 통합 포인트: `MapView`에서 **선택 이벤트**를 통합 store에 기록하고, 선택된 케이스/로케이션을 레이어 스타일에 반영.

### 2.3 Right Ops Panel (기존+확장)

| Component | Responsibility | 통합 변경 |
|---|---|---|
| `RightPanel` | 위치 상태 요약 + 차트 | 상단에 `HvdcKpiStrip` 삽입 + 공용 필터 섹션 추가 |
| `HeaderBar` | 상단 헤더/토글 | 통합 필터/라이브 토글 배치 |

---

## 3) Frontend — apps/hvdc-dashboard

### 3.1 기존 핵심 UI

| Component | Responsibility | Notes |
|---|---|---|
| `Dashboard` | KPI + Worklist + DetailDrawer 조립 | `/api/worklist` fetch 후 store에 apply |
| `KpiStrip` | KPI 카드 스트립 | store의 `kpis`, `lastRefreshAt` 사용 |
| `WorklistTable` | Worklist 렌더링/정렬/클릭 | row click → `selectedCase` 설정 |
| `DetailDrawer` | 케이스 상세 패널(overlay/sidepanel) | 통합 시 bottom panel/overlay로 재배치 |
| `SavedViewsBar` | 저장된 필터 뷰 | 통합 시 URL 반영 고려 |
| `WorklistToolbar` | 필터/검색 | 통합 store와 일치 필요 |

### 3.2 API(현행)

| Endpoint | Purpose | 통합 전략 |
|---|---|---|
| `/api/worklist` | Worklist + KPI 집계 | Phase 2까지 유지 → Phase 3에서 Supabase RPC로 이관 |

---

## 4) packages/hvdc-workbench (권장 신규 패키지)

> 통합의 핵심은 “HVDC UI를 logistics 앱에 끼워넣는 것”이므로, HVDC 컴포넌트를 패키지로 추출하면 재사용/회귀가 쉬워집니다.

### 4.1 모듈 구조(예시)

```text
packages/hvdc-workbench/
  src/
    components/
      KpiStrip.tsx
      WorklistTable.tsx
      DetailDrawer.tsx
      WorklistToolbar.tsx
      SavedViewsBar.tsx
    store/
      hvdcStore.ts
    data/
      hvdcApi.ts   # supabase rpc or api route wrapper
    types/
      hvdc.ts
```

### 4.2 공개 API(권장)

```ts
export function HvdcKpiStrip(props: { filters: HvdcFilters }): JSX.Element
export function HvdcWorkbench(props: {
  mode?: 'embedded' | 'standalone'
  onCaseSelect?: (caseId: string) => void
}): JSX.Element
```

- `mode=embedded`: logistics dashboard에 삽입될 때 UI 밀도/height 제한 적용
- `mode=standalone`: 기존 hvdc-dashboard에서 전체 화면으로 사용

---

## 5) 공용 상태관리(권장)

### 5.1 Unified Store (packages/shared 또는 apps/logistics-dashboard)

> 반드시 하나의 store에 “선택/필터”를 모읍니다.

```ts
interface OpsStore {
  selectedCaseId?: string
  selectedLocationId?: string
  filters: {
    gate?: 'RED'|'AMBER'|'GREEN'|'ZERO'
    site?: string
    vendor?: string
    timeWindowH: number
  }
  ui: {
    bottomOpen: boolean
    rightOpen: boolean
    liveEnabled: boolean
  }
  actions: {
    selectCase(id?: string): void
    selectLocation(id?: string): void
    setFilter(patch: Partial<OpsStore['filters']>): void
  }
}
```

### 5.2 이벤트 동기화 규칙

- **Single Source of Selection**: selection은 store만 수정
- Map/Worklist는 store를 구독하여 하이라이트/필터 갱신
- URL 동기화는 Phase 2에서 선택 적용(딥링크)

---

## 6) Data Layer (Supabase)

### 6.1 Client/Server 분리

- Client: `createBrowserClient` (anon key)
- Server: `createServerClient` (service role key 사용 가능)

### 6.2 데이터 호출 표준(권장)

- `rpc_get_worklist(filters)`
- `rpc_get_kpis(filters)`
- `rpc_get_map_locations(filters)`
- `rpc_get_case_detail(case_id)`

> Phase 2까지는 `hvdcApi.ts`가 `/api/worklist`도 지원(어댑터 패턴).

---

## 7) ETL/RDF 파이프라인(요약)

| Module | Responsibility | Output |
|---|---|---|
| `json_to_ttl.py` | JSON→TTL, 컬럼 SSOT 적용, used_cols 생성 | `output/*.ttl`, `*.used_cols.json` |
| `flow_code_calc.py` | Flow Code v3.5 계산 | case/event 분류 |
| `column_audit.py` | 입력 컬럼 인벤토리 | `reports/columns_inventory.json` |
| `run_status_pipeline.py` | 통합 파이프라인 실행 | Supabase upsert + TTL |

---

## 8) Feasibility Review

- 추출 난이도: **중간** (경로/alias/상태 의존성 정리 필요)
- 추천 PR 순서:
  1) hvdc-workbench 패키지 생성 + 기존 hvdc-dashboard가 패키지 사용하도록 리팩토링
  2) logistics-dashboard에서 hvdc-workbench 임베드
  3) store 통합 및 selection 동기화

Status: **PASS**
