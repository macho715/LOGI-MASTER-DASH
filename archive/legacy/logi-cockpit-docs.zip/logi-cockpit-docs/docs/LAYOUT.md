# SYSTEM LAYOUT — Map-centric 3패널 UI (Desktop + Mobile)

## 1) 레이아웃 목표

- **지도 중심(Map-centric)**: 지도는 “업무 상황판의 캔버스”로 항상 시야의 중심
- **조치까지 한 화면**: 우측/하단 패널에서 KPI 확인 → Worklist 선택 → Detail에서 조치
- **한 가지 사실(SSOT)**: Map, Worklist, KPI는 같은 `case_id`와 이벤트 기반 계산을 공유

---

## 2) Desktop 레이아웃(권장)

### 2.1 그리드(예시)

- Header: 고정 56px
- Main: 2열(지도/패널)
- Bottom: Workbench(Worklist + Detail) 영역

```mermaid
flowchart TB
  H[Header 56px]
  subgraph Row1[Main Row]
    M[Map Canvas (60~65%)] --- R[Right Ops Panel (35~40%)]
  end
  subgraph Row2[Bottom Row]
    B[Bottom Workbench Panel (Map 아래 full width 또는 Map+Right 하단 split)]
  end
  H --> Row1 --> Row2
```

### 2.2 Layout 옵션 2가지

#### 옵션 A) Bottom이 **전체 폭(full width)**

- 장점: Worklist가 넓어져 테이블 밀도/가독성↑
- 단점: 지도 세로 높이가 줄어듦

```
┌──────────────────────── Header ────────────────────────┐
│                                                        │
├────────────── Map (좌) ───────────────┬─ Right (우) ───┤
│                                       │ KPI/Status     │
│                                       │ Filters        │
│                                       │ Mini charts     │
├──────────────────── Bottom (하) — Workbench ────────────┤
│ Worklist Table + Detail Drawer(overlay/inline)          │
└────────────────────────────────────────────────────────┘
```

#### 옵션 B) Bottom이 **Map 아래만** (우측 패널은 고정)

- 장점: 우측 패널 KPI/상태가 항상 고정
- 단점: Worklist 가로폭 제한

```
┌──────────────────────── Header ────────────────────────┐
├────────────── Map (좌) ───────────────┬─ Right (우) ───┤
│                                       │ KPI + Status    │
├──────────── Bottom (Map 아래) ────────┤                  │
│ Worklist / Detail                      │                  │
└─────────────────────────────────────────────────────────┘
```

> 권장: **옵션 A(Full width)** — Worklist는 ‘의사결정 테이블’이므로 가로 폭을 최대 확보하는 편이 운영 효율이 높습니다.

---

## 3) 패널 구성(우측/하단)

### 3.1 Right Ops Panel (우측)

**섹션 순서(권장):**

1. **HVDC KPI Strip** (DRI/WSI/Red/Overdue/Recoverable/Last Refresh)
2. **Map/Worklist 공통 필터**
   - Gate(RED/AMBER/GREEN/ZERO)
   - Project/Site/Vendor
   - Time Window(예: last 24h)
3. **Logistics Status Summary**
   - Location status table
   - Occupancy bar chart
   - Status distribution pie

> Right panel은 “상황 요약 + 필터” 역할. 상세 읽기는 Bottom/Drawer에서 처리.

### 3.2 Bottom Workbench Panel (하단)

**기본 구조(권장):**

- 좌측: `WorklistTable`
- 우측(또는 overlay): `DetailDrawer`

**상호작용:**
- Worklist row 클릭 → `selected_case_id` 설정 → Detail open
- Detail에서 탭: Timeline / Docs / Exceptions / Actions

---

## 4) 핵심 인터랙션(시그니처 2개)

### Signature #1 — Map ↔ Worklist “양방향 드릴다운”

- Map marker 클릭
  - 해당 location/site와 연결된 케이스로 Worklist 자동 필터
  - Worklist 상단에 “Map Filter Applied” 배지 표시
- Worklist row 클릭
  - 지도에서 해당 케이스의 위치를 하이라이트(색/펄스)
  - ETA wedge 또는 geofence 강조

### Signature #2 — “Gate-first” 운영 필터

- 우측 패널에서 Gate(RED/AMBER/…​) 토글
- Map heat/marker 색상과 Worklist 결과가 즉시 동기화
- KPI strip도 같은 필터를 반영해 변동

---

## 5) Mobile 레이아웃(권장)

### 5.1 구조

- Map이 전체 화면
- Bottom sheet: Worklist (snap: 20%/50%/90%)
- Right panel은 아이콘 버튼으로 slide-over

```text
[Header]
[Map full]
[Bottom Sheet: Worklist]
[SlideOver: Filters/KPI]
```

### 5.2 제스처

- Bottom sheet drag(위/아래)
- Row 클릭 시 Detail은 overlay로 열고, 스와이프로 닫기

---

## 6) 접근성/WCAG 2.2 AA 체크(핵심)

- **키보드 내비게이션:** Worklist row는 `button` 또는 `role=row` + `tabIndex`로 접근 가능
- **포커스 가시성:** 드로어 열림 시 포커스 트랩, 닫힘 시 트리거로 복귀
- **색상 의존 금지:** Gate/Status는 색+라벨+아이콘 동시 제공
- **모션 배려:** `prefers-reduced-motion` 시 지도 하이라이트 애니메이션 최소화

---

## 7) 구현 스캐폴딩(예시)

> 실제 적용은 `apps/logistics-dashboard` 내부에서 통합 레이아웃 컴포넌트를 만들고, hvdc-workbench 패키지를 삽입하는 방식이 가장 안전합니다.

```tsx
// app/(dashboard)/page.tsx (예시)
export default function OpsCockpitPage() {
  return (
    <Shell>
      <Header />
      <MainGrid>
        <MapSlot>
          <MapView />
        </MapSlot>
        <RightSlot>
          <OpsRightPanel />
        </RightSlot>
        <BottomSlot>
          <HvdcWorkbench />
        </BottomSlot>
      </MainGrid>
    </Shell>
  )
}
```

Feasibility: **PASS** (기존 MapView/RightPanel/HVDC 패널을 조합하는 수준)
