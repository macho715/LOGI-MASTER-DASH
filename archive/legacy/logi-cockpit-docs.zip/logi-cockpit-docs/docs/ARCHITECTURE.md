# SYSTEM ARCHITECTURE — Supabase SSOT + Map-centric Ops Cockpit

## 1) 한 문장 비전

> **Supabase 단일 SSOT** 위에서, **온톨로지 이벤트(Date Canon)** 를 기준으로 KPI/Worklist/Map을 계산하고, **하나의 화면**(Map 중심)에서 운영 의사결정과 조치를 끝낸다.

## 2) 시스템 구성요소(고수준)

### 2.1 시스템 경계

- **Client (Browser)**: Next.js 앱의 Client Components(Map, Charts, Interactions)
- **Next.js Server**: API Routes/Server Actions, SSR/RSC(가능한 부분), Auth
- **Supabase**
  - Postgres (SSOT)
  - Realtime (초기: DB Changes, Scale: Broadcast+Trigger)
  - Storage (원본 파일/산출물 보관)
  - Auth (선택)
- **ETL/Scripts**: JSON/Excel → Events 정규화 → DB upsert → TTL 산출

### 2.2 C4 스타일 컨텍스트(개념)

```mermaid
flowchart LR
  U[Ops User] -->|Browser| A[Next.js Apps]
  A -->|SQL/RPC| S[(Supabase Postgres)]
  A -->|Realtime subscribe| R[Supabase Realtime]
  P[ETL Scripts] -->|Upsert| S
  P -->|Upload| ST[Supabase Storage]
  S -->|Trigger| R
```

---

## 3) 데이터 아키텍처 (SSOT)

> 원칙: **UI는 계산을 분산해서 하지 않는다.** 가능한 한 **DB View/RPC**에서 집계된 동일 결과를 가져오고, 화면은 렌더링/상호작용에만 집중한다.

### 3.1 핵심 테이블(최소 권장)

| Table | Purpose | Key Columns |
|------|---------|------------|
| `cases` | 케이스/선적 단위 마스터 | `case_id (uuid)`, `hvdc_code`, `ship_no`, `vendor`, `project` |
| `events` | 온톨로지 기반 이벤트(표준) | `event_id`, `case_id`, `event_type`, `event_ts`, `event_date_dubai`, `source` |
| `locations` | 지도 표출 대상 위치 | `location_id`, `name`, `lat`, `lng`, `type(site/warehouse)` |
| `geofences` | 위치 지오펜스 | `geofence_id`, `location_id`, `geom(polygon)` |
| `location_statuses` | 위치 상태(현재) | `location_id`, `status_code`, `occupancy_rate`, `last_updated` |
| `occupancy_snapshots` | 점유율 타임시리즈 | `location_id`, `ts`, `occupancy_rate` |
| `worklist_items` *(옵션)* | UI 캐시/스냅샷 | `case_id`, `gate`, `overdue`, `computed_at` |

#### Date Canon 구현 제안

- `event_ts`는 **UTC timestamp**로 저장
- `event_date_dubai`는 **Asia/Dubai** 기준 운영 일자를 고정
  - 구현 옵션 A: ETL에서 변환 후 upsert
  - 구현 옵션 B: Postgres generated column / view에서 `(event_ts AT TIME ZONE 'Asia/Dubai')::date`

### 3.2 집계 레이어(View/RPC)

| Layer | Name (예시) | Returns |
|------|-------------|---------|
| View/MV | `worklist_v` 또는 `worklist_mv` | Worklist rows (gate/overdue/recoverable/…) |
| RPC | `rpc_get_worklist(filters jsonb)` | 위와 동일(필터 포함) |
| RPC | `rpc_get_kpis(filters jsonb)` | KPI strip 데이터 |
| RPC | `rpc_get_case_detail(case_id uuid)` | Detail Drawer(타임라인/문서/예외) |
| RPC | `rpc_get_map_locations(filters jsonb)` | Map marker/heat/eta 용 데이터 |

> 초기 단계에서는 **기존 HVDC `/api/worklist`를 유지**하고, Phase 3에서 RPC/MV로 이관(동등성 테스트 필수).

### 3.3 온톨로지 매핑

- 온톨로지 개념(`event_type`)은 **문서/TTL의 클래스/속성**과 1:1로 연결
- `configs/columns.hvdc_status.json`는 ETL의 컬럼 매핑 SSOT
- `scripts/*`는 JSON/Excel 입력을 이벤트(표준)로 정규화

---

## 4) 애플리케이션 아키텍처

### 4.1 앱 구성

- `apps/logistics-dashboard`
  - 기본 Map 엔진 + RightPanel
  - 통합 후: `packages/hvdc-workbench`를 우/하 패널에 삽입
- `apps/hvdc-dashboard`
  - 독립 운영(회귀/비교용) — 통합 전후 결과 비교 기준점

### 4.2 프론트 상태 구조(권장)

> “한 화면” UX의 핵심은 **선택/필터의 단일화**입니다.

```mermaid
flowchart TB
  subgraph Store[Zustand Unified Store]
    S1[selected_case_id]
    S2[selected_location_id]
    S3[filters: gate/site/vendor/time_window]
    S4[ui: panel_open, sheet_snap]
  end

  Map[MapView] <-->|select/highlight| Store
  Worklist[WorklistTable] <-->|select/filter| Store
  Detail[DetailDrawer] <-->|open/close| Store
  Right[RightPanel] --> Store
```

### 4.3 데이터 페칭 원칙

- 초기 로딩(데이터) : 가능한 한 **서버에서 병렬로** 가져오고(예: `Promise.all`), 클라이언트에는 최소 JSON만 전달
- Map/차트는 client-only 이므로, map library는 **동적 import**로 분리
- 동일 데이터 중복 요청 방지: store 레벨에서 dedupe/caching

---

## 5) Realtime(실시간) 설계

### 단계적 적용 전략

1) **Phase 0–2:**
- 단순 polling 또는 DB Changes 구독(부하 낮음)

2) **Phase 3–5:**
- DB 트리거가 핵심 테이블 변경 시 Realtime **Broadcast**로 이벤트 발행
- 클라이언트는 단일 채널(`ops_updates`)을 구독하여 store를 갱신

### 메시지 스키마(예시)

```json
{
  "type": "EVENT_UPSERT" | "LOCATION_STATUS_UPDATE" | "WORKLIST_REFRESH",
  "case_id": "uuid",
  "location_id": "string",
  "ts": "2026-01-23T12:34:56Z",
  "payload": { "...": "..." }
}
```

---

## 6) 보안/권한(RLS) 원칙

- `anon` 역할: 읽기 전용(필요한 view/rpc만)
- `service_role`: ETL 업로드/관리 작업 전용
- Row Level Security(RLS):
  - 테넌트/프로젝트 분리 필요 시 `project_id` 기준 정책
  - 외부 공유가 필요한 테이블은 반드시 view로 제한

---

## 7) 관측성/운영

- ETL 로그: `scripts` 실행 로그 + Supabase에 `etl_runs` 테이블 적재(권장)
- 데이터 품질: SHACL 실패/used_cols 변동을 주간 리포트로 알림
- 성능: worklist RPC p95, map API p95, realtime 지연 p95 측정

---

## 8) Feasibility Review

- 기술 난이도: **중간**
- 리스크: 키/날짜 일원화, 집계 성능, 실시간 부하
- 선행 조건: `case_id` 공용키 합의 + events 스키마 확정

Status: **PASS (Revise with Data Gate)**
