# ROADMAP — 통합 로드맵 (Map-centric Ops Cockpit)

> 목적: **일정/범위/검증 기준을 명확히** 하여, “통합이 언제/어디까지 되었는가”를 팀이 동일하게 인지하도록 합니다.

## 0) Executive Summary

- **Phase 1 (1–2주):** Monorepo 구조 생성 + 3패널 레이아웃 뼈대 + 공용 Store/Key 합의
- **Phase 2 (2–3주):** HVDC UI 모듈화(패키지화) + Map↔Worklist↔Detail 동기화
- **Phase 3 (2–3주):** Supabase 스키마 통합 + Events 중심 Date Canon + RPC/뷰 단일화
- **Phase 4 (1–2주):** Flow Code v3.5/SHACL 검증 자동화 + 운영 알림
- **Phase 5 (상시):** Realtime/Broadcast 고도화 + 성능 최적화

> 성공 기준: “한 화면에서” 동일 `case_id`를 기준으로 지도/워크리스트/드로어가 일관되게 동작하며, 데이터 SSOT가 Supabase로 단일화됨.

---

## 1) Phase 0 — 설계 고정(0.5–2일)

### Deliverables
- [ ] `docs/LAYOUT.md` 초안(그리드/모바일 포함)
- [ ] `docs/ARCHITECTURE.md` 초안(데이터/Realtime)
- [ ] `case_id`/`hvdc_code` 키 전략 확정
- [ ] Date Canon 정의: `events(event_type, event_date_dubai)`

### Acceptance Criteria
- 팀 합의 문서가 남아 있고(SSOT), 이후 구현 PR은 이 문서를 기준으로 리뷰 가능

---

## 2) Phase 1 — Monorepo 구조 생성(1–2주)

### Work Items
1. Repo 이관
- [ ] `/apps/logistics-dashboard`로 v0 프로젝트 이관
- [ ] `/apps/hvdc-dashboard`로 HVDC 프로젝트 이관

2. 패키지/공유 레이어
- [ ] `/packages/ui-components` 생성(공용 Card, Table, Drawer 등)
- [ ] `/packages/shared` 생성(types/time/zod/schema)

3. 배치/온톨로지
- [ ] `/scripts`로 logiontology_scaffold 이관
- [ ] `/configs`로 `columns.hvdc_status.json` SSOT 고정

### Acceptance Criteria
- 로컬에서 **두 앱이 동시에** 빌드/실행 가능
- 공용 패키지 import가 정상 동작

---

## 3) Phase 2 — 레이아웃 통합(2–3주)

### Work Items
1. 3패널 레이아웃(데스크탑)
- [ ] `MapView(좌)` + `RightPanel(우)` + `HVDC Bottom Panel(하)`

2. 동기화 이벤트
- [ ] Worklist row 클릭 → Map highlight + Detail open
- [ ] Map marker 클릭 → Worklist filter + Detail open

3. 모바일 UX
- [ ] Bottom panel을 bottom sheet로 전환(드래그/스냅)
- [ ] Right panel을 slide-over drawer로 전환

### Acceptance Criteria
- p95 상호작용 지연 ≤ 200ms(로컬 기준)
- 상태(선택/필터)가 URL 또는 store 기준으로 재현 가능

---

## 4) Phase 3 — 데이터 통합(Supabase SSOT)(2–3주)

### Work Items
1. 스키마
- [ ] `events` 중심 정규화 스키마 도입
- [ ] Map 데이터: `locations`, `geofences`, `location_statuses`, `occupancy_snapshot`

2. 집계
- [ ] `/api/worklist` 로직을 **Supabase RPC/뷰**로 이관(동등 결과 보장)
- [ ] KPI/Worklist/Map이 동일 RPC/뷰를 사용

3. 보안
- [ ] RLS 정책 + 서비스 롤 분리

### Acceptance Criteria
- Worklist/KPI 재현성 ≥ 99%
- 집계 API p95 ≤ 800ms (프로덕션 유사 환경)

---

## 5) Phase 4 — Flow Code/SHACL/운영 자동화(1–2주)

### Work Items
- [ ] Flow Code v3.5 계산 결과를 DB에 적재(혹은 RPC 계산)
- [ ] SHACL 검증을 CI/배치에 포함
- [ ] 품질 게이트 알림(누락 이벤트 급증 등)

### Acceptance Criteria
- 품질 게이트 위반 0건 또는 예외 리스트가 자동 생성됨

---

## 6) Phase 5 — Realtime 고도화/성능(상시)

### Work Items
- [ ] Realtime 구독 전략 정리(DB Changes → Broadcast/Trigger)
- [ ] Map 라이브러리 번들 최적화(동적 import)
- [ ] MV refresh/인덱스 튜닝

### Acceptance Criteria
- 실시간 갱신 지연 p95 ≤ 1.5s
- 대시보드 상호 불일치 0건/일

---

## 7) 의사결정 게이트(Decision Gates)

| Gate | 질문 | 통과 조건 |
|------|------|----------|
| G1 | 레이아웃/상태 동기화가 UX적으로 자연스러운가? | 조작 3회 이내에 원하는 케이스 상세 접근 가능 |
| G2 | SSOT가 정말 단일화 되었는가? | 동일 `case_id`의 값이 UI/리포트에서 불일치하지 않음 |
| G3 | 성능이 충분한가? | p95 상호작용 ≤ 200ms, 초기 로딩에 map 번들 지연 로딩 |
| G4 | 운영 가능한가? | 배치 실패 알림/재시도/로그가 남음 |

---

## 8) Simulation Log (PoC 권장)

> 아래는 “재현 가능한 최소 시뮬레이션”을 위한 체크리스트입니다.

- [ ] **Layout PoC:** CSS grid로 3패널 구현 후, map hover/zoom 시 레이아웃 흔들림 없는지 확인
- [ ] **Sync PoC:** `selected_case_id` store 하나로 Map/Worklist/Detail이 동기화 되는지 확인
- [ ] **RPC PoC:** (동일 필터) `/api/worklist` vs `rpc_get_worklist()` 결과가 일치하는지 샘플 200건 비교

Feasibility: **PASS** (기존 두 앱 모두 Next.js + Zustand 기반이라 구조적 난이도는 중간)
